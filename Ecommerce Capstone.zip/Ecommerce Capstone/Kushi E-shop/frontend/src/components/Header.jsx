import React, { useState } from 'react';
import { Navbar, Nav, Container, NavDropdown, Badge } from 'react-bootstrap';
import { FaShoppingCart, FaUser } from 'react-icons/fa';
import { Link } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { useLogoutMutation } from '../slices/usersApiSlice';
import { logout } from '../slices/authSlice';
import SearchBox from './SearchBox';
import logo from '../assets/logo.png';
import './Header.css';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error(error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return <div>Oops! Something went wrong.</div>;
    }

    return this.props.children;
  }
}

const Header = () => {
  const { cartItems } = useSelector((state) => state.cart);
  const { userInfo } = useSelector((state) => state.auth);

  const dispatch = useDispatch();
  const [logoutApiCall] = useLogoutMutation();

  const [womenDropdownOpen, setWomenDropdownOpen] = useState(false);
  const [menDropdownOpen, setMenDropdownOpen] = useState(false);
  const [kidsDropdownOpen, setKidsDropdownOpen] = useState(false);

  const openWomenDropdown = () => {
    setWomenDropdownOpen(true);
    setMenDropdownOpen(false);
    setKidsDropdownOpen(false);
  };

  const openMenDropdown = () => {
    setMenDropdownOpen(true);
    setWomenDropdownOpen(false);
    setKidsDropdownOpen(false);
  };

  const openKidsDropdown = () => {
    setKidsDropdownOpen(true);
    setWomenDropdownOpen(false);
    setMenDropdownOpen(false);
  };

  const closeDropdowns = () => {
    setWomenDropdownOpen(false);
    setMenDropdownOpen(false);
    setKidsDropdownOpen(false);
  };

  const logoutHandler = async () => {
    try {
      await logoutApiCall().unwrap();
      dispatch(logout());
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <ErrorBoundary>
      <header>
        <Navbar bg="primary" variant="dark" expand="lg" collapseOnSelect>
          <Container>
            <Link to="/" className="navbar-brand">
              <img
                src={logo}
                alt="Logo"
                className="logo"
                style={{ width: '100px' }}
              />
            </Link>

            <Navbar.Toggle aria-controls="basic-navbar-nav" />

            <Navbar.Collapse id="basic-navbar-nav">
              <Nav className="ms-auto search-box">
                <SearchBox />

                <Link to="/cart" className="nav-link cart-link">
                  <FaShoppingCart size={30} /> Cart
                  {cartItems.length > 0 && (
                    <Badge pill bg="success" style={{ marginLeft: '5px' }}>
                      {cartItems.reduce((a, c) => a + c.qty, 0)}
                    </Badge>
                  )}
                </Link>

                {userInfo ? (
                  <>
                    <NavDropdown title={userInfo.name} id="username">
                      <Link to="/profile" className="dropdown-item">
                        Profile
                      </Link>
                      <NavDropdown.Item onClick={logoutHandler}>
                        Logout
                      </NavDropdown.Item>
                    </NavDropdown>
                  </>
                ) : (
                  <Link to="/login" className="nav-link sign-in-link">
                    <FaUser size={25} /> Sign In
                  </Link>
                )}

                {userInfo && userInfo.isAdmin && (
                  <NavDropdown title="Admin" id="adminmenu">
                    <Link to="/admin/productlist" className="dropdown-item">
                      Products
                    </Link>
                    <Link to="/admin/orderlist" className="dropdown-item">
                      Orders
                    </Link>
                    <Link to="/admin/userlist" className="dropdown-item">
                      Users
                    </Link>
                  </NavDropdown>
                )}
              </Nav>
            </Navbar.Collapse>
          </Container>
        </Navbar>

        <Navbar bg="light" expand="lg" className="nav-2" collapseOnSelect>
          <Container>
            <Navbar.Toggle aria-controls="navbarNav" />

            <Navbar.Collapse id="navbarNav" className="justify-content-center">
              <Nav>
                <Link to="/" exact="true" className="nav-link">
                  Home
                </Link>
                <Link to="/allproducts" className="nav-link">
                  All Products
                </Link>

                <NavDropdown
                  title="Women"
                  id="navbarDropdownWomen"
                  show={womenDropdownOpen}
                  onMouseEnter={openWomenDropdown}
                  onMouseLeave={closeDropdowns}
                >
                  <Link to="/women-kurti" className="dropdown-item">
                    Kurtis
                  </Link>
                  <Link to="/women-pant" className="dropdown-item">
                    Pants
                  </Link>
                  <Link to="/women-skirts" className="dropdown-item">
                    Skirts
                  </Link>
                </NavDropdown>
                <NavDropdown
                  title="Men"
                  id="navbarDropdownMen"
                  show={menDropdownOpen}
                  onMouseEnter={openMenDropdown}
                  onMouseLeave={closeDropdowns}
                >
                  <Link to="/men-shirts" className="dropdown-item">
                    Shirts
                  </Link>
                  <Link to="/men-pants" className="dropdown-item">
                    Pants
                  </Link>
                  <Link to="/men-shoes" className="dropdown-item">
                    Shoes
                  </Link>
                </NavDropdown>
                <NavDropdown
                  title="Kids"
                  id="navbarDropdownKids"
                  show={kidsDropdownOpen}
                  onMouseEnter={openKidsDropdown}
                  onMouseLeave={closeDropdowns}
                >
                  <Link to="/girl-babies" className="dropdown-item">
                    Girl Baby Dress
                  </Link>
                  <Link to="/boy-babies" className="dropdown-item">
                    Boy Baby Dress
                  </Link>
                  <Link to="/toys" className="dropdown-item">
                    Toys
                  </Link>
                </NavDropdown>
                <Link to="/contact" className="nav-link">
                  Contact
                </Link>
              </Nav>
            </Navbar.Collapse>
          </Container>
        </Navbar>
      </header>
    </ErrorBoundary>
  );
};

export default Header;
