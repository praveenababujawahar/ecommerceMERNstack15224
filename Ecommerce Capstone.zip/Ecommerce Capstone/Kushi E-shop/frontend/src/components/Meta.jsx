import { Helmet } from 'react-helmet-async';

// Meta component for setting the page title, description, and keywords
const Meta = ({ title, description, keywords }) => {
  return (
    <Helmet>
      <title>{title}</title> {/* Set the page title */}
      <meta name='description' content={description} /> {/* Set the page description */}
      <meta name='keyword' content={keywords} /> {/* Set the page keywords */}
    </Helmet>
  );
};

// Set default props for the Meta component
Meta.defaultProps = {
  title: 'Welcome To Kushi E-shop', // Default page title
  description: 'We sell the best products for cheap', // Default page description
  keywords: 'women dresses, men dresses, kids fashion', // Default page keywords
};

export default Meta;

