import { Row, Col } from 'react-bootstrap';
import { useParams } from 'react-router-dom';
import { useGetAllProductsQuery } from '../../slices/productsApiSlice';
import { Link } from 'react-router-dom';
import Product from '../../components/Product';
import Loader from '../../components/Loader';
import Message from '../../components/Message';
import ProductCarousel from '../../components/ProductCarousel';
import Meta from '../../components/Meta';

const MenShirts = () => {
  const { pageNumber, keyword } = useParams();

  const { data, isLoading, error } = useGetAllProductsQuery({
    keyword,
    pageNumber,
  });

  return (
    <>
      {!keyword ? (
        <ProductCarousel />
      ) : (
        <Link to='/' className='btn btn-light mb-4'>
          Go Back
        </Link>
      )}
      {isLoading ? (
        <Loader />
      ) : error ? (
        <Message variant='danger'>
          {error?.data?.message || error.error}
        </Message>
      ) : (
        <>
          <Meta />
          <div style={{ textAlign: 'center' }}>
            <h1>Men Shirts</h1>
          </div>
          <Row>
            {data.products
              .filter(product => product.category === 'Men Shirts')
              .map((product) => (
                <Col key={product._id} sm={12} md={6} lg={4} xl={3}>
                  <Product product={product} />
                </Col>
              ))}
          </Row>
        </>
      )}
    </>
  );
};

export default MenShirts;
