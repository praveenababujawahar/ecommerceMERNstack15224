// Create a middleware function that handles asynchronous operations
const asyncHandler = (fn) => (req, res, next) =>
  // Wrap the asynchronous function in a Promise and catch any errors
  Promise.resolve(fn(req, res, next)).catch(next);

// Export the asyncHandler middleware function as the default export
export default asyncHandler;

