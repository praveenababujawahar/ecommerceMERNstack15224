// Middleware to handle "Not Found" errors
const notFound = (req, res, next) => {
  // Create a new Error instance with a message indicating the requested URL that was not found
  const error = new Error(`Not Found - ${req.originalUrl}`);
  res.status(404); // Set the response status to 404 (Not Found)
  next(error); // Pass the error to the next middleware or error handler
};

// Error handler middleware
const errorHandler = (err, req, res, next) => {
  let statusCode = res.statusCode === 200 ? 500 : res.statusCode;
  let message = err.message;

  // NOTE: checking for invalid ObjectId moved to it's own middleware
  // See README for further info.

  // Set the response status to the determined status code
  res.status(statusCode).json({
    message: message, // Set the response message to the error message
    stack: process.env.NODE_ENV === 'production' ? null : err.stack, // Include the error stack trace in non-production environments
  });
};

// Export the notFound and errorHandler middleware functions
export { notFound, errorHandler };
