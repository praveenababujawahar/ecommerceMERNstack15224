import mongoose from 'mongoose';
import dotenv from 'dotenv';
import colors from 'colors';
import users from './data/users.js';
import products from './data/products.js';
import User from './models/userModel.js';
import Product from './models/productModel.js';
import Order from './models/orderModel.js';
import connectDB from './config/db.js';

dotenv.config();

// Connect to MongoDB database
connectDB();

// Function to import data into the database
const importData = async () => {
  try {
    // Delete existing data from collections
    await Order.deleteMany();
    await Product.deleteMany();
    await User.deleteMany();

    // Insert users into User collection and retrieve the created users
    const createdUsers = await User.insertMany(users);

    // Get the admin user ID
    const adminUser = createdUsers[0]._id;

    // Map and modify products, assigning the admin user as the owner
    const sampleProducts = products.map((product) => {
      return { ...product, user: adminUser };
    });

    // Insert sample products into Product collection
    await Product.insertMany(sampleProducts);

    console.log('Data Imported!'.green.inverse);
    process.exit();
  } catch (error) {
    console.error(`${error}`.red.inverse);
    process.exit(1);
  }
};

// Function to destroy data in the database
const destroyData = async () => {
  try {
    // Delete all data from collections
    await Order.deleteMany();
    await Product.deleteMany();
    await User.deleteMany();

    console.log('Data Destroyed!'.red.inverse);
    process.exit();
  } catch (error) {
    console.error(`${error}`.red.inverse);
    process.exit(1);
  }
};

// Check command line argument to determine import or destroy operation
if (process.argv[2] === '-d') {
  destroyData();
} else {
  importData();
}
