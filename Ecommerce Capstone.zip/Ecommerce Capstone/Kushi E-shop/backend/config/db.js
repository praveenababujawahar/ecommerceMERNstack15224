import mongoose from 'mongoose';

// Function to establish connection with MongoDB database
const connectDB = async () => {
  try {
    // Attempt to connect to the MongoDB database using the provided URI
    const conn = await mongoose.connect(process.env.MONGO_URI);
    console.log(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    // Log and handle any errors that occur during the connection process
    console.error(`Error: ${error.message}`);
    process.exit(1);
  }
};

// Export the connectDB function as the default export of the module
export default connectDB;
