import mongoose from 'mongoose';

// Define the order schema
const orderSchema = mongoose.Schema(
  {
    // User associated with the order
    user: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: 'User',
    },
    // Array of order items
    orderItems: [
      {
        // Name of the item
        name: { type: String, required: true },
        // Quantity of the item
        qty: { type: Number, required: true },
        // Image URL of the item
        image: { type: String, required: true },
        // Price of the item
        price: { type: Number, required: true },
        // Product associated with the item
        product: {
          type: mongoose.Schema.Types.ObjectId,
          required: true,
          ref: 'Product',
        },
      },
    ],
    // Shipping address
    shippingAddress: {
      // Street address
      address: { type: String, required: true },
      // City
      city: { type: String, required: true },
      // Postal code
      postalCode: { type: String, required: true },
      // Country
      country: { type: String, required: true },
    },
    // Payment method
    paymentMethod: {
      type: String,
      required: true,
    },
    // Payment result
    paymentResult: {
      // Payment ID
      id: { type: String },
      // Payment status
      status: { type: String },
      // Update time of payment
      update_time: { type: String },
      // Email address associated with payment
      email_address: { type: String },
    },
    // Total price of the items
    itemsPrice: {
      type: Number,
      required: true,
      default: 0.0,
    },
    // Tax price
    taxPrice: {
      type: Number,
      required: true,
      default: 0.0,
    },
    // Shipping price
    shippingPrice: {
      type: Number,
      required: true,
      default: 0.0,
    },
    // Total order price
    totalPrice: {
      type: Number,
      required: true,
      default: 0.0,
    },
    // Flag indicating if the order is paid
    isPaid: {
      type: Boolean,
      required: true,
      default: false,
    },
    // Date of payment
    paidAt: {
      type: Date,
    },
    // Flag indicating if the order is delivered
    isDelivered: {
      type: Boolean,
      required: true,
      default: false,
    },
    // Date of delivery
    deliveredAt: {
      type: Date,
    },
  },
  // Include timestamps for createdAt and updatedAt fields
  {
    timestamps: true,
  }
);

// Create the Order model using the order schema
const Order = mongoose.model('Order', orderSchema);

// Export the Order model as the default export
export default Order;
