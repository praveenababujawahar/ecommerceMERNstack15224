import mongoose from 'mongoose';

// Define the review schema
const reviewSchema = mongoose.Schema(
  {
    // Name of the reviewer
    name: { type: String, required: true },
    // Rating given by the reviewer
    rating: { type: Number, required: true },
    // Comment provided by the reviewer
    comment: { type: String, required: true },
    // User associated with the review
    user: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: 'User',
    },
  },
  // Include timestamps for createdAt and updatedAt fields
  {
    timestamps: true,
  }
);

// Define the product schema
const productSchema = mongoose.Schema(
  {
    // User associated with the product
    user: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: 'User',
    },
    // Name of the product
    name: {
      type: String,
      required: true,
    },
    // Image URL of the product
    image: {
      type: String,
      required: true,
    },
    // Brand of the product
    brand: {
      type: String,
      required: true,
    },
    // Category of the product
    category: {
      type: String,
      required: true,
    },
    // Description of the product
    description: {
      type: String,
      required: true,
    },
    // Reviews associated with the product
    reviews: [reviewSchema],
    // Average rating of the product
    rating: {
      type: Number,
      required: true,
      default: 0,
    },
    // Number of reviews for the product
    numReviews: {
      type: Number,
      required: true,
      default: 0,
    },
    // Price of the product
    price: {
      type: Number,
      required: true,
      default: 0,
    },
    // Count of the product in stock
    countInStock: {
      type: Number,
      required: true,
      default: 0,
    },
  },
  // Include timestamps for createdAt and updatedAt fields
  {
    timestamps: true,
  }
);

// Create the Product model using the product schema
const Product = mongoose.model('Product', productSchema);

// Export the Product model as the default export
export default Product;
