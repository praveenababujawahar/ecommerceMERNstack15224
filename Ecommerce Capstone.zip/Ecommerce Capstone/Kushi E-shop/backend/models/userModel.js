import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

// Define the user schema
const userSchema = mongoose.Schema(
  {
    // Name of the user
    name: {
      type: String,
      required: true,
    },
    // Email of the user
    email: {
      type: String,
      required: true,
      unique: true,
    },
    // Password of the user
    password: {
      type: String,
      required: true,
    },
    // Flag indicating if the user is an admin
    isAdmin: {
      type: Boolean,
      required: true,
      default: false,
    },
  },
  // Include timestamps for createdAt and updatedAt fields
  {
    timestamps: true,
  }
);

// Method to match user entered password to hashed password in the database
userSchema.methods.matchPassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

// Middleware to encrypt the password using bcrypt before saving the user
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) {
    next();
  }

  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
});

// Create the User model using the user schema
const User = mongoose.model('User', userSchema);

// Export the User model as the default export
export default User;
