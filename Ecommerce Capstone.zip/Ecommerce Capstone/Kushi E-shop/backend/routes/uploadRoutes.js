import path from 'path';
import express from 'express';
import multer from 'multer';

const router = express.Router();

// Configure multer storage options
const storage = multer.diskStorage({
  destination(req, file, cb) {
    cb(null, 'uploads/');
  },
  filename(req, file, cb) {
    cb(
      null,
      `${file.fieldname}-${Date.now()}${path.extname(file.originalname)}`
    );
  },
});

// Define file filter function
function fileFilter(req, file, cb) {
  // Define allowed file extensions and mimetypes
  const filetypes = /jpe?g|png|webp/;
  const mimetypes = /image\/jpe?g|image\/png|image\/webp/;

  // Check if the file extension and mimetype match the allowed types
  const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
  const mimetype = mimetypes.test(file.mimetype);

  if (extname && mimetype) {
    cb(null, true);
  } else {
    cb(new Error('Images only!'), false);
  }
}

// Create multer instance with storage and file filter options
const upload = multer({ storage, fileFilter });

// Set up middleware to handle single image uploads
const uploadSingleImage = upload.single('image');

// Define the route for uploading an image
router.post('/', (req, res) => {
  // Call the upload middleware to process the image upload
  uploadSingleImage(req, res, function (err) {
    if (err) {
      res.status(400).send({ message: err.message });
    }

    res.status(200).send({
      message: 'Image uploaded successfully',
      image: `/${req.file.path}`,
    });
  });
});

// Export the router
export default router;
