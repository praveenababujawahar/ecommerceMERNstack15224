import express from 'express';
const router = express.Router();

// Import product controller methods
import {
  getProducts,
  getAllProducts,
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct,
  createProductReview,
  getTopProducts,
} from '../controllers/productController.js';

// Import authentication and authorization middleware
import { protect, admin } from '../middleware/authMiddleware.js';

// Import custom middleware for checking ObjectId validity
import checkObjectId from '../middleware/checkObjectId.js';

// Define routes and associated controller methods
router.route('/').get(getAllProducts).post(protect, admin, createProduct);
router.get('/paginate', getProducts);
// Route for getting all products and creating a new product
// Accessible to all users for getting products, and only to authenticated
// admin users for creating a product
router.route('/:id/reviews').post(protect, checkObjectId, createProductReview);
// Route for creating a new product review, requires authentication and valid ObjectId
router.get('/top', getTopProducts);
// Route for getting top-rated products, accessible to all users
router
  .route('/:id')
  .get(checkObjectId, getProductById)
  .put(protect, admin, checkObjectId, updateProduct)
  .delete(protect, admin, checkObjectId, deleteProduct);
// Route for getting, updating, and deleting a product by ID
// Requires valid ObjectId, authentication, and admin access for updating and deleting

// Export the router
export default router;
