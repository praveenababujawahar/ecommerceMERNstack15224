import express from 'express';
const router = express.Router();

// Import order controller methods
import {
  addOrderItems,
  getMyOrders,
  getOrderById,
  updateOrderToPaid,
  updateOrderToDelivered,
  getOrders,
} from '../controllers/orderController.js';

// Import authentication and authorization middleware
import { protect, admin } from '../middleware/authMiddleware.js';

// Define routes and associated controller methods
router.route('/').post(protect, addOrderItems).get(protect, admin, getOrders);
// Route for creating a new order item, accessible only to authenticated users
// and requires admin access for listing all orders
router.route('/mine').get(protect, getMyOrders);
// Route for fetching an order by ID, accessible only to authenticated users
router.route('/:id').get(protect, getOrderById);
// Route for updating order payment status, accessible only to authenticated users
router.route('/:id/pay').put(protect, updateOrderToPaid);
// Route for updating order delivery status, accessible only to authenticated admin users
router.route('/:id/deliver').put(protect, admin, updateOrderToDelivered);

// Export the router
export default router;
