import express from 'express';

// Import user controller methods
import {
  authUser,
  registerUser,
  logoutUser,
  getUserProfile,
  updateUserProfile,
  getUsers,
  deleteUser,
  getUserById,
  updateUser,
} from '../controllers/userController.js';

// Import authentication and authorization middleware
import { protect, admin } from '../middleware/authMiddleware.js';

const router = express.Router();

// Define routes and associated controller methods
router.route('/').post(registerUser).get(protect, admin, getUsers);
// Route for registering a new user and getting all users
// Accessible to all users for registration, and only to authenticated
// admin users for getting all users
router.post('/auth', authUser);
// Route for authenticating a user and getting a token
// Accessible to all users for authentication
router.post('/logout', logoutUser);
// Route for logging out a user and clearing the token
// Accessible to all users for logging out
router
  .route('/profile')
  .get(protect, getUserProfile)
  .put(protect, updateUserProfile);
// Route for getting and updating user profile
// Requires authentication for both getting and updating
router
  .route('/:id')
  .delete(protect, admin, deleteUser)
  .get(protect, admin, getUserById)
  .put(protect, admin, updateUser);
// Route for deleting, getting, and updating a user by ID
// Requires authentication, admin access, and valid user ID

// Export the router
export default router;
