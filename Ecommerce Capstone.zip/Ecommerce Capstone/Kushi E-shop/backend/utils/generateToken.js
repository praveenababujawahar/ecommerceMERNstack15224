import jwt from 'jsonwebtoken';

// Function to generate a JWT token
const generateToken = (res, userId) => {
  // Generate the token using jwt.sign() method
  const token = jwt.sign({ userId }, process.env.JWT_SECRET, {
    expiresIn: '30d', // Token expiration time (30 days)
  });

  // Set the generated token as an HTTP-Only cookie
  res.cookie('jwt', token, {
    httpOnly: true, // Cookie cannot be accessed by JavaScript
    secure: process.env.NODE_ENV !== 'development', // Use secure cookies in production environment
    sameSite: 'strict', // Prevent cross-site request forgery (CSRF) attacks
    maxAge: 30 * 24 * 60 * 60 * 1000, // Maximum age of the cookie (30 days)
  });
};

// Export the generateToken function as the default export of the module
export default generateToken;
